@echo off

cd /d "%~dp0"

python -m pip install ".\minecraftPythonAPI.zip"

pause